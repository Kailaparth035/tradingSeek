/*!
 * react-native-multi-select
 * Copyright(c) 2017 Mustapha Babatunde Oluwaleke
 * MIT Licensed
 */
import MultiSelect from './lib/react-native-multi-select';

export default MultiSelect;
